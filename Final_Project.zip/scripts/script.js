/*
    Student Name: Gracia Assaka
    File Name: script.js
    Date: April 13, 2022
*/
//slideshow

//jQuery for hero image to consume the header window space
$(document).ready(function(){
	 $('.hero').height($(window).height());
});

$(document).ready(function(){
	 $('.hero_1').height($(window).height());
});

$(document).ready(function() {
  var slideIndex = 1;

  function showSlides(n) {
    var slides = $(".mySlides");
    var i;

    if (n > slides.length) {
      slideIndex = 1;
    }

    if (n < 1) {
      slideIndex = slides.length;
    }

    for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
    }

    slides[slideIndex - 1].style.display = "block";
  }

  function plusSlides(n) {
    showSlides(slideIndex += n);
  }

  showSlides(slideIndex);

  $(".prev").click(function() {
    plusSlides(-1);
  });

  $(".next").click(function() {
    plusSlides(1);
  });

});

let slideIndex = 0;
showSlides();

function showSlides() {
  let i;
  let slides = document.getElementsByClassName("mySlides_1");
  let dots = document.getElementsByClassName("dot_1");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 2000); // Change image every 2 seconds
}